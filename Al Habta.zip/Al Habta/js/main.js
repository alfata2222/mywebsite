jQuery(document).ready(function () {
    
    "use strict"
   $('.slider').ripples({
     dropRadius: 13,
     perturbance: 0.01,

   });
    

    
    var typed = new Typed('.text', {
  /**
   * @property {array} strings strings to be typed
   * @property {string} stringsElement ID of element containing string children
   */
  strings: [
    '<strong>We aim to continue</strong><strong>to grow our company</strong>',
    '<strong>in a</strong><strong>professional manner</strong>',
    '<strong>both in</strong><strong> Oman and internationally</strong>',
    '<strong>Our strength lies in</strong><strong> our ability</strong>',
    '<strong>to combine local</strong><strong> and international expertise</strong>',
    '<strong>and apply the depth of our</strong><strong> specialist experience</strong>'
  ],

  /**
   * @property {number} typeSpeed type speed in milliseconds
   */
  typeSpeed: 65,
  loop: true
    });
    
     
});